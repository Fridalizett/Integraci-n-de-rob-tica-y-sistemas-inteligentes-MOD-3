#!/usr/bin/env python3
import rospy
import numpy as np
import math

from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import Odometry


class RobotStatePublisher: 
    def __init__(self):
        # Inicialización del nodo
        rospy.init_node("RobotStatePublisher")

        # Variables para la posición del robot
        self.time = rospy.Time.now()
        self.odom_msg = Odometry()
        self.robot_pose = PoseStamped()

        # Suscripción al tópico de Odometría
        self.odom_sub = rospy.Subscriber('/odom', Odometry, self.odom_callback)

        # Publicador para la posición del robot
        self.pose_pub = rospy.Publisher("/pose_ideal", PoseStamped, queue_size=10)

        # Configuración de la frecuencia de publicación
        rospy.Timer(rospy.Duration(1.0/50), self.publish_robot_pose)

    def publish_robot_pose(self, _):
        # Actualización de la posición del robot
        self.robot_pose.pose.position.x = self.odom_msg.pose.pose.position.x
        self.robot_pose.pose.position.y = self.odom_msg.pose.pose.position.y
        self.robot_pose.pose.orientation.z = self.odom_msg.pose.pose.orientation.z

        # Publicación de la posición del robot
        self.pose_pub.publish(self.robot_pose)
        
    def odom_callback(self, msg):
        # Actualización del mensaje de Odometría
        self.odom_msg = msg

if __name__ == '__main__':
    RSP = RobotStatePublisher()

    try:
        rospy.spin()
            
    except rospy.ROSInterruptException:
        pass
