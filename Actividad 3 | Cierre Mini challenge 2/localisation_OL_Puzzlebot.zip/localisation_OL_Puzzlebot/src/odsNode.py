import rospy
import os
from nav_msgs.msg import Odometry
from std_msgs.msg import Bool
from geometry_msgs.msg import PoseStamped, Pose

class OdsNode:
    def __init__(self):
        rospy.init_node('ods_writer_node')

        rospy.Subscriber('/pose_ideal', PoseStamped, self.poseIdeal_callback)
        rospy.Subscriber('/ods_signal', Bool, self.signal_status)

        self.ideal_file_path = os.path.expanduser('~/catkin_ws/src/localisation_openloop/src/data.txt')

        self.robot_pos_ideal = {
            'odom_ideal': None,
        }

        self.flag = False
        self.publish_ideal_position = False

    def signal_status(self, msg):
        if self.flag != msg.data:
            self.flag = msg.data

    def poseIdeal_callback(self, msg):
        if self.flag and not self.publish_ideal_position:
            self.robot_pos_ideal['odom_ideal'] = (
                msg.pose.orientation.z
            )
            self.write_to_txt(self.robot_pos_ideal, self.ideal_file_path)
            self.publish_ideal_position = True

    def write_to_txt(self, dictionary, filename):
        rospy.loginfo("Writing to text file...")
        with open(filename, 'a') as txt_file:
            for key, position in dictionary.items():
                if position is not None:
                    rospy.loginfo("working")
                    txt_file.write(f'{position}\n')


        rospy.loginfo("Writing to text file completed.")

if __name__ == '__main__':
    try:
        ods_node = OdsNode()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
